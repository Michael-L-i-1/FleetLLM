//! TODO: Port reference.c dedupe_rows. Keep FIRST record for each exact ID in
//! original order. Return each repeated ID once, sorted lexicographically, in
//! the second vector. IDs are case sensitive. Do not mutate the input.
use crate::Record;

pub fn dedupe(rows: &[Record]) -> (Vec<Record>, Vec<String>) {
    let mut seen = Vec::new();
    let mut out = Vec::with_capacity(rows.len());
    let mut dup_ids = Vec::new();
    let mut dup_seen = Vec::new();
    for r in rows {
        let mut found = false;
        for s in &seen {
            if s == &r.id {
                found = true;
                break;
            }
        }
        if found {
            // duplicate occurrence
            let mut already = false;
            for d in &dup_seen {
                if d == &r.id {
                    already = true;
                    break;
                }
            }
            if !already {
                dup_ids.push(r.id.clone());
                dup_seen.push(r.id.clone());
            }
        } else {
            seen.push(r.id.clone());
            out.push(r.clone());
        }
    }
    dup_ids.sort();
    (out, dup_ids)
}
