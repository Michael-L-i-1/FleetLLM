//! TODO: Port reference.c money functions. Do not use floating point.
//! parse accepts optional +/- then >=1 ASCII digit, optionally '.' with 1 or 2
//! digits. Reject whitespace, exponents, missing parts, extra precision, overflow.
//! Return exact cents (i64 range). format always emits two decimals, no '+' or
//! redundant leading zeroes; formatting i64::MIN must also work.
pub fn parse(text: &str) -> Option<i64> {
    let bytes = text.as_bytes();
    if bytes.is_empty() {
        return None;
    }
    let mut i = 0;
    let mut neg = false;
    if bytes[i] == b'-' || bytes[i] == b'+' {
        neg = bytes[i] == b'-';
        i += 1;
        if i >= bytes.len() {
            return None;
        }
    }
    // at least one digit before dot
    let mut whole_str = String::new();
    let mut has_digit = false;
    while i < bytes.len() && bytes[i].is_ascii_digit() {
        has_digit = true;
        whole_str.push(bytes[i] as char);
        i += 1;
    }
    if !has_digit {
        return None;
    }
    // parse whole as u128
    let whole: u128 = match whole_str.parse::<u128>() {
        Ok(v) => v,
        Err(_) => return None,
    };
    let mut frac: u32 = 0;
    if i < bytes.len() && bytes[i] == b'.' {
        i += 1;
        if i >= bytes.len() || !bytes[i].is_ascii_digit() {
            return None;
        }
        // first fraction digit
        let d1 = (bytes[i] - b'0') as u32;
        i += 1;
        frac = d1 * 10;
        if i < bytes.len() && bytes[i].is_ascii_digit() {
            let d2 = (bytes[i] - b'0') as u32;
            i += 1;
            frac += d2;
            // no third fraction digit
            if i < bytes.len() && bytes[i].is_ascii_digit() {
                return None;
            }
        } else {
            // exactly one fraction digit is allowed
        }
    }
    // no remaining characters
    if i != bytes.len() {
        return None;
    }
    // overflow check
    let total = whole.checked_mul(100)?.checked_add(frac as u128)?;
    let limit_pos = i64::MAX as u128;
    let limit_neg = 9_223_372_036_854_775_808u128; // abs(i64::MIN)
    let limit = if neg { limit_neg } else { limit_pos };
    if total > limit {
        return None;
    }
    let cents_i128 = total as i128;
    let cents = if neg {
        if total == limit_neg {
            i64::MIN
        } else {
            -(cents_i128 as i64)
        }
    } else {
        cents_i128 as i64
    };
    Some(cents)
}

pub fn format(cents: i64) -> String {
    let sign = if cents < 0 { "-" } else { "" };
    let abs = (cents as i128).abs();
    let int_part = abs / 100;
    let frac_part = (abs % 100) as u32;
    format!("{}{}.{:02}", sign, int_part, frac_part)
}
