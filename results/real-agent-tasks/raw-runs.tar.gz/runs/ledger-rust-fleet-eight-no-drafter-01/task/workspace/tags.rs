//! TODO: Port reference.c tags_parse. Split on ';', trim ASCII whitespace,
//! skip empty segments; lowercase ASCII. Nonempty labels may contain only ASCII
//! letters/digits/'_'/'-'. Return sorted unique labels, or None if any is invalid.
pub fn parse(text: &str) -> Option<Vec<String>> {
    let mut labels = Vec::new();
    for segment in text.split(';') {
        // trim ASCII whitespace
        let trimmed = segment.trim_matches(|c: char| c.is_ascii_whitespace());
        if trimmed.is_empty() {
            continue;
        }
        // lowercase ASCII
        let lowered: String = trimmed.chars().map(|c| {
            if c.is_ascii_uppercase() { c.to_ascii_lowercase() } else { c }
        }).collect();
        // validate characters
        for ch in lowered.chars() {
            if !(ch.is_ascii_alphanumeric() || ch == '_' || ch == '-') {
                return None;
            }
        }
        labels.push(lowered);
    }
    labels.sort();
    labels.dedup();
    Some(labels)
}
