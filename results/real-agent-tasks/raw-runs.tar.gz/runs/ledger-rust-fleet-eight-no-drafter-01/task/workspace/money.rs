//! TODO: Port reference.c money functions. Do not use floating point.
//! parse accepts optional +/- then >=1 ASCII digit, optionally '.' with 1 or 2
//! digits. Reject whitespace, exponents, missing parts, extra precision, overflow.
//! Return exact cents (i64 range). format always emits two decimals, no '+' or
//! redundant leading zeroes; formatting i64::MIN must also work.
pub fn parse(text: &str) -> Option<i64> {
    if text.is_empty() {
        return None;
    }
    let mut chars = text.chars().peekable();
    let mut neg = false;
    if let Some(c) = chars.peek() {
        if *c == '+' || *c == '-' {
            neg = *c == '-';
            chars.next();
            if chars.peek().is_none() {
                return None;
            }
        }
    }
    // first digit required
    let mut whole: u128 = 0;
    let mut has_digit = false;
    while let Some(&c) = chars.peek() {
        if c.is_ascii_digit() {
            has_digit = true;
            let d = c as u128 - '0' as u128;
            whole = whole.checked_mul(10)?.checked_add(d)?;
            chars.next();
        } else {
            break;
        }
    }
    if !has_digit {
        return None;
    }
    let mut frac: u128 = 0;
    let mut frac_digits = 0;
    if let Some(&'.') = chars.peek() {
        chars.next(); // consume '.'
        // need at least one digit
        let mut first_frac = false;
        while let Some(&c) = chars.peek() {
            if c.is_ascii_digit() {
                if frac_digits == 0 {
                    first_frac = true;
                }
                let d = c as u128 - '0' as u128;
                frac = frac.checked_mul(10)?.checked_add(d)?;
                frac_digits += 1;
                if frac_digits > 2 {
                    return None;
                }
                chars.next();
            } else {
                break;
            }
        }
        if !first_frac {
            return None;
        }
        // pad to two digits
        if frac_digits == 1 {
            frac *= 10;
        }
        // no more chars allowed
        if chars.peek().is_some() {
            return None;
        }
    } else {
        // no dot, must be end
        if chars.peek().is_some() {
            return None;
        }
    }
    // total cents
    let total = whole.checked_mul(100)?.checked_add(frac)?;
    let max_abs_pos = i64::MAX as u128;
    let max_abs_neg = 9_223_372_036_854_775_808u128;
    if neg {
        if total > max_abs_neg {
            return None;
        }
        if total == max_abs_neg {
            return Some(i64::MIN);
        } else {
            let v = -(total as i64);
            return Some(v);
        }
    } else {
        if total > max_abs_pos {
            return None;
        }
        Some(total as i64)
    }
}

pub fn format(cents: i64) -> String {
    let sign = if cents < 0 { "-" } else { "" };
    let abs_i128 = (cents as i128).abs();
    let abs_u128 = abs_i128 as u128;
    let int_part = abs_u128 / 100;
    let frac_part = (abs_u128 % 100) as u32;
    format!("{}{}.{:02}", sign, int_part, frac_part)
}
