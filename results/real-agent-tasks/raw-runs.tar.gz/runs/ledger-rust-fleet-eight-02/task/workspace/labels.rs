//! TODO: Port reference.c normalize: trim/collapse ASCII whitespace to one
//! ordinary space; lowercase ASCII A-Z; preserve non-ASCII characters unchanged.
pub fn normalize(text: &str) -> String {
    fn is_ascii_ws(c: char) -> bool {
        matches!(c, ' ' | '\t' | '\n' | '\r' | '\u{000b}' | '\u{000c}')
    }
    let mut out = String::new();
    let mut pending = false;
    for ch in text.chars() {
        if is_ascii_ws(ch) {
            if !out.is_empty() {
                pending = true;
            }
        } else {
            if pending {
                out.push(' ');
                pending = false;
            }
            let ch_low = if ch.is_ascii_uppercase() { (ch as u8 + 32) as char } else { ch };
            out.push(ch_low);
        }
    }
    out
}
