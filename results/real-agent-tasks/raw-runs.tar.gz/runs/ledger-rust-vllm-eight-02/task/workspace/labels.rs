//! TODO: Port reference.c normalize: trim/collapse ASCII whitespace to one
//! ordinary space; lowercase ASCII A-Z; preserve non-ASCII characters unchanged.
pub fn normalize(text: &str) -> String {
    let mut out = String::new();
    let mut pending_space = false;
    for c in text.chars() {
        if c.is_ascii_whitespace() {
            pending_space = true;
        } else {
            if pending_space {
                if !out.is_empty() {
                    out.push(' ');
                }
                pending_space = false;
            }
            if c.is_ascii_uppercase() {
                out.push((c as u8 + 32) as char);
            } else {
                out.push(c);
            }
        }
    }
    if pending_space && !out.is_empty() {
        out.pop();
    }
    out
}
