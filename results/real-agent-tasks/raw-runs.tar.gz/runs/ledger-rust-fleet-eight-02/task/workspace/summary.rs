//! TODO: Port reference.c group_rows. Group by exact vendor string, count rows,
//! sum signed cents, and sort by vendor lexicographically. Include zero totals.
//! Inputs in this task never overflow i64 when summed.
use crate::Record;
pub fn group(rows: &[Record]) -> Vec<(String, usize, i64)> {
    if rows.is_empty() {
        return Vec::new();
    }
    let mut sorted: Vec<&Record> = rows.iter().collect();
    sorted.sort_by(|a, b| a.vendor.cmp(&b.vendor));
    let mut result = Vec::new();
    let mut i = 0;
    while i < sorted.len() {
        let vendor = sorted[i].vendor.clone();
        let mut count = 0usize;
        let mut total: i64 = 0;
        while i < sorted.len() && sorted[i].vendor == vendor {
            count += 1;
            total = total.wrapping_add(sorted[i].cents);
            i += 1;
        }
        result.push((vendor, count, total));
    }
    result
}
