//! TODO: Port reference.c dedupe_rows. Keep FIRST record for each exact ID in
//! original order. Return each repeated ID once, sorted lexicographically, in
//! the second vector. IDs are case sensitive. Do not mutate the input.
use crate::Record;
use std::collections::HashSet;

pub fn dedupe(rows: &[Record]) -> (Vec<Record>, Vec<String>) {
    let mut seen = HashSet::new();
    let mut out = Vec::with_capacity(rows.len());
    let mut dup_set = HashSet::new();
    for r in rows {
        if seen.contains(&r.id) {
            // duplicate occurrence
            dup_set.insert(r.id.clone());
        } else {
            seen.insert(r.id.clone());
            out.push(r.clone());
        }
    }
    let mut duplicates: Vec<String> = dup_set.into_iter().collect();
    duplicates.sort();
    (out, duplicates)
}
