//! TODO: Port reference.c filter_rows. Return cloned records with inclusive
//! from <= date <= to, preserving input order. Invalid endpoints or from>to
//! return an empty vector. Use crate::date::valid for endpoint checks.
use crate::Record;
pub fn between(rows: &[Record], from: &str, to: &str) -> Vec<Record> {
    if !crate::date::valid(from) || !crate::date::valid(to) { return Vec::new(); }
    if from > to { return Vec::new(); }
    let mut out = Vec::new();
    for r in rows {
        if r.date >= from && r.date <= to {
            out.push(r.clone());
        }
    }
    out
}
