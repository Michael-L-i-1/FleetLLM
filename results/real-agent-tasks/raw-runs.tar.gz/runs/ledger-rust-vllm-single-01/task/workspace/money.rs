//! TODO: Port reference.c money functions. Do not use floating point.
//! parse accepts optional +/- then >=1 ASCII digit, optionally '.' with 1 or 2
//! digits. Reject whitespace, exponents, missing parts, extra precision, overflow.
//! Return exact cents (i64 range). format always emits two decimals, no '+' or
//! redundant leading zeroes; formatting i64::MIN must also work.
pub fn parse(text: &str) -> Option<i64> {
    let bytes = text.as_bytes();
    if bytes.is_empty() { return None; }
    let mut i = 0;
    let mut neg = false;
    let first = bytes[0] as char;
    if first == '+' || first == '-' {
        neg = first == '-';
        i += 1;
        if i >= bytes.len() { return None; }
    }
    if !bytes[i].is_ascii_digit() { return None; }
    let mut whole: u128 = 0;
    while i < bytes.len() && bytes[i].is_ascii_digit() {
        let d = (bytes[i] - b'0') as u128;
        whole = whole.checked_mul(10)?.checked_add(d)?;
        i += 1;
    }
    let mut frac: u128 = 0;
    let mut frac_digits = 0;
    if i < bytes.len() && bytes[i] == b'.' {
        i += 1;
        if i >= bytes.len() || !bytes[i].is_ascii_digit() { return None; }
        // first fraction digit
        let d = (bytes[i] - b'0') as u128;
        frac = d * 10;
        frac_digits = 1;
        i += 1;
        if i < bytes.len() && bytes[i].is_ascii_digit() {
            let d2 = (bytes[i] - b'0') as u128;
            frac += d2;
            frac_digits = 2;
            i += 1;
        }
        // no more fraction digits allowed
        if i < bytes.len() && bytes[i].is_ascii_digit() { return None; }
    }
    if i != bytes.len() { return None; }
    // overflow check
    let total_cents_u128 = whole.checked_mul(100)?.checked_add(frac)?;
    let max_abs: u128 = 9_223_372_036_854_775_808u128; // i64::MIN abs
    if total_cents_u128 > max_abs { return None; }
    // For positive, max is i64::MAX
    let max_pos: u128 = 9_223_372_036_854_775_807u128;
    if !neg && total_cents_u128 > max_pos { return None; }
    let cents_i128 = total_cents_u128 as i128;
    let cents_i64 = if neg {
        if total_cents_u128 == max_abs {
            i64::MIN
        } else {
            -(cents_i128 as i64)
        }
    } else {
        cents_i128 as i64
    };
    Some(cents_i64)
}

pub fn format(cents: i64) -> String {
    let sign = if cents < 0 { "-" } else { "" };
    // absolute value safely
    let abs_u128 = if cents == i64::MIN {
        9_223_372_036_854_775_808u128
    } else if cents < 0 {
        (-(cents as i128)) as u128
    } else {
        cents as u128
    };
    let whole = abs_u128 / 100;
    let frac = abs_u128 % 100;
    format!("{}{}.{:02}", sign, whole, frac)
}
