//! TODO: Port reference.c group_rows. Group by exact vendor string, count rows,
//! sum signed cents, and sort by vendor lexicographically. Include zero totals.
//! Inputs in this task never overflow i64 when summed.
use crate::Record;
pub fn group(rows: &[Record]) -> Vec<(String, usize, i64)> {
    let mut map: Vec<(String, usize, i64)> = Vec::new();
    for r in rows {
        if let Some(entry) = map.iter_mut().find(|(v, _, _)| v == &r.vendor) {
            entry.1 += 1;
            entry.2 = entry.2.saturating_add(r.cents);
        } else {
            map.push((r.vendor.clone(), 1, r.cents));
        }
    }
    map.sort_by(|a, b| a.0.cmp(&b.0));
    map
}
