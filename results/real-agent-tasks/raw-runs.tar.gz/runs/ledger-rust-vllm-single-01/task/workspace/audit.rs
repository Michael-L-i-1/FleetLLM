//! TODO: Port reference.c dedupe_rows. Keep FIRST record for each exact ID in
//! original order. Return each repeated ID once, sorted lexicographically, in
//! the second vector. IDs are case sensitive. Do not mutate the input.
use crate::Record;
pub fn dedupe(rows: &[Record]) -> (Vec<Record>, Vec<String>) {
    let mut seen = Vec::new();
    let mut kept = Vec::new();
    let mut dup_set = Vec::new();
    for r in rows {
        if seen.contains(&r.id) {
            if !dup_set.contains(&r.id) {
                dup_set.push(r.id.clone());
            }
        } else {
            seen.push(r.id.clone());
            kept.push(r.clone());
        }
    }
    dup_set.sort();
    (kept, dup_set)
}
