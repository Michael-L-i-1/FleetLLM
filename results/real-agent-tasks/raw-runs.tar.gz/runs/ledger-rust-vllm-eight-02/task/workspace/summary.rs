//! TODO: Port reference.c group_rows. Group by exact vendor string, count rows,
//! sum signed cents, and sort by vendor lexicographically. Include zero totals.
//! Inputs in this task never overflow i64 when summed.
use crate::Record;

pub fn group(rows: &[Record]) -> Vec<(String, usize, i64)> {
    use std::collections::BTreeMap;
    let mut map: BTreeMap<String, (usize, i64)> = BTreeMap::new();
    for r in rows {
        let entry = map.entry(r.vendor.clone()).or_insert((0, 0));
        entry.0 += 1;
        entry.1 = entry.1.wrapping_add(r.cents);
    }
    map.into_iter()
        .map(|(vendor, (count, total))| (vendor, count, total))
        .collect()
}
