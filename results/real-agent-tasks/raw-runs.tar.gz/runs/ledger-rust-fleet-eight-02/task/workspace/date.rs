//! TODO: Port reference.c date_valid: exact ASCII YYYY-MM-DD, Gregorian date,
//! year 0001..9999, actual month length and century-aware leap years.
pub fn valid(text: &str) -> bool {
    let bytes = text.as_bytes();
    if bytes.len() != 10 {
        return false;
    }
    if bytes[4] != b'-' || bytes[7] != b'-' {
        return false;
    }
    // digits at positions 0-3,5-6,8-9
    for (i, &b) in bytes.iter().enumerate() {
        if i == 4 || i == 7 {
            continue;
        }
        if !b.is_ascii_digit() {
            return false;
        }
    }
    let year = parse_u16(&bytes[0..4]) as u32;
    let month = parse_u8(&bytes[5..7]) as u32;
    let day = parse_u8(&bytes[8..10]) as u32;
    if year == 0 || year > 9999 {
        return false;
    }
    if month < 1 || month > 12 {
        return false;
    }
    if day < 1 {
        return false;
    }
    let days_in_month = match month {
        1 => 31,
        2 => {
            if is_leap(year) { 29 } else { 28 }
        }
        3 => 31,
        4 => 30,
        5 => 31,
        6 => 30,
        7 => 31,
        8 => 31,
        9 => 30,
        10 => 31,
        11 => 30,
        12 => 31,
        _ => 0,
    };
    day <= days_in_month
}

fn parse_u16(b: &[u8]) -> u16 {
    let mut v = 0u16;
    for &c in b {
        v = v * 10 + (c - b'0') as u16;
    }
    v
}

fn parse_u8(b: &[u8]) -> u8 {
    let mut v = 0u8;
    for &c in b {
        v = v * 10 + (c - b'0') as u8;
    }
    v
}

fn is_leap(y: u32) -> bool {
    (y % 4 == 0) && (y % 100 != 0 || y % 400 == 0)
}
