//! TODO: Port reference.c date_valid: exact ASCII YYYY-MM-DD, Gregorian date,
//! year 0001..9999, actual month length and century-aware leap years.
pub fn valid(text: &str) -> bool {
    let bytes = text.as_bytes();
    if bytes.len() != 10 {
        return false;
    }
    if bytes[4] != b'-' || bytes[7] != b'-' {
        return false;
    }
    // all other chars must be ASCII digits
    for (i, &b) in bytes.iter().enumerate() {
        if i == 4 || i == 7 {
            continue;
        }
        if !b.is_ascii_digit() {
            return false;
        }
    }
    // parse year
    let mut year: u32 = 0;
    for i in 0..4 {
        year = year * 10 + (bytes[i] - b'0') as u32;
    }
    // parse month
    let mut month: u32 = 0;
    for i in 5..7 {
        month = month * 10 + (bytes[i] - b'0') as u32;
    }
    // parse day
    let mut day: u32 = 0;
    for i in 8..10 {
        day = day * 10 + (bytes[i] - b'0') as u32;
    }
    if year < 1 || year > 9999 {
        return false;
    }
    if month < 1 || month > 12 {
        return false;
    }
    let days_in_month = match month {
        1 => 31,
        2 => {
            let leap = (year % 4 == 0) && (year % 100 != 0 || year % 400 == 0);
            if leap { 29 } else { 28 }
        }
        3 => 31,
        4 => 30,
        5 => 31,
        6 => 30,
        7 => 31,
        8 => 31,
        9 => 30,
        10 => 31,
        11 => 30,
        12 => 31,
        _ => 0,
    };
    if day < 1 || day > days_in_month {
        return false;
    }
    true
}
