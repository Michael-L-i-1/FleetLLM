//! TODO: Port reference.c tags_parse. Split on ';', trim ASCII whitespace,
//! skip empty segments; lowercase ASCII. Nonempty labels may contain only ASCII
//! letters/digits/'_'/'-'. Return sorted unique labels, or None if any is invalid.
pub fn parse(text: &str) -> Option<Vec<String>> {
    let mut labels: Vec<String> = Vec::new();
    for segment in text.split(';') {
        let trimmed = trim_ascii_whitespace(segment);
        if trimmed.is_empty() { continue; }
        // validate characters
        let mut ok = true;
        let mut lowered = String::with_capacity(trimmed.len());
        for ch in trimmed.chars() {
            if ch.is_ascii_alphabetic() {
                let lc = ch.to_ascii_lowercase();
                lowered.push(lc);
            } else if ch.is_ascii_digit() || ch == '_' || ch == '-' {
                lowered.push(ch);
            } else {
                ok = false;
                break;
            }
        }
        if !ok { return None; }
        labels.push(lowered);
    }
    // sort and dedupe
    labels.sort();
    labels.dedup();
    Some(labels)
}

fn trim_ascii_whitespace(s: &str) -> &str {
    let bytes = s.as_bytes();
    let mut start = 0;
    let mut end = bytes.len();
    while start < end && is_ascii_ws(bytes[start]) { start += 1; }
    while end > start && is_ascii_ws(bytes[end - 1]) { end -= 1; }
    &s[start..end]
}
fn is_ascii_ws(b: u8) -> bool {
    matches!(b, b' ' | b'\t' | b'\n' | b'\r' | b'\x0b' | b'\x0c')
}
