//! TODO: Port reference.c money functions. Do not use floating point.
//! parse accepts optional +/- then >=1 ASCII digit, optionally '.' with 1 or 2
//! digits. Reject whitespace, exponents, missing parts, extra precision, overflow.
//! Return exact cents (i64 range). format always emits two decimals, no '+' or
//! redundant leading zeroes; formatting i64::MIN must also work.
pub fn parse(text: &str) -> Option<i64> {
    let bytes = text.as_bytes();
    if bytes.is_empty() {
        return None;
    }
    let mut pos = 0usize;
    let mut neg = false;
    if bytes[0] == b'+' || bytes[0] == b'-' {
        neg = bytes[0] == b'-';
        pos += 1;
        if pos >= bytes.len() {
            return None;
        }
    }
    // whole part
    let mut whole: u128 = 0;
    let mut whole_digits = 0usize;
    while pos < bytes.len() && bytes[pos].is_ascii_digit() {
        whole_digits += 1;
        let d = (bytes[pos] - b'0') as u128;
        whole = whole.checked_mul(10)?.checked_add(d)?;
        pos += 1;
    }
    if whole_digits == 0 {
        return None;
    }
    let mut frac: u32 = 0;
    let mut frac_digits = 0usize;
    if pos < bytes.len() && bytes[pos] == b'.' {
        pos += 1;
        if pos >= bytes.len() || !bytes[pos].is_ascii_digit() {
            return None;
        }
        // first fraction digit
        let d1 = (bytes[pos] - b'0') as u32;
        frac = d1 * 10;
        frac_digits = 1;
        pos += 1;
        if pos < bytes.len() && bytes[pos].is_ascii_digit() {
            let d2 = (bytes[pos] - b'0') as u32;
            frac += d2;
            frac_digits = 2;
            pos += 1;
            // third fraction digit not allowed
            if pos < bytes.len() && bytes[pos].is_ascii_digit() {
                return None;
            }
        }
    }
    // no extra characters
    if pos != bytes.len() {
        return None;
    }
    // compute total cents
    let total_cents_u128 = whole.checked_mul(100)?.checked_add(frac as u128)?;
    let limit_abs: u128 = if neg {
        9_223_372_036_854_775_808u128
    } else {
        9_223_372_036_854_775_807u128
    };
    if total_cents_u128 > limit_abs {
        return None;
    }
    let cents_i64 = if neg {
        if total_cents_u128 == 9_223_372_036_854_775_808u128 {
            i64::MIN
        } else {
            -(total_cents_u128 as i64)
        }
    } else {
        total_cents_u128 as i64
    };
    Some(cents_i64)
}

pub fn format(cents: i64) -> String {
    let sign = if cents < 0 { "-" } else { "" };
    let abs_i128 = if cents == i64::MIN {
        9_223_372_036_854_775_808i128
    } else {
        (cents.abs() as i128)
    };
    let abs_u128 = abs_i128 as u128;
    let int_part = abs_u128 / 100;
    let frac_part = (abs_u128 % 100) as u32;
    format!("{}{}.{:02}", sign, int_part, frac_part)
}
