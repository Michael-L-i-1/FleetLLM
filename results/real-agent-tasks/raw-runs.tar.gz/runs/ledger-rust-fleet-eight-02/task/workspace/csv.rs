//! TODO: Port reference.c csv_parse. One CSV record, comma separated; empty
//! fields allowed. Quotes only at field start, doubled quotes escape a quote,
//! quoted fields may contain commas. After closing quote only comma/end allowed.
//! Reject unclosed/stray quotes and CR/LF anywhere. Preserve all field contents.
pub fn parse_line(text: &str) -> Option<Vec<String>> {
    if text.chars().any(|c| c == '\r' || c == '\n') {
        return None;
    }
    let mut chars = text.chars().peekable();
    let mut fields = Vec::new();

    loop {
        // If no more chars, break after pushing last field
        let mut field = String::new();
        let mut quoted = false;
        if let Some(&c) = chars.peek() {
            if c == '"' {
                quoted = true;
                chars.next(); // consume opening quote
                let mut closed = false;
                while let Some(c2) = chars.next() {
                    if c2 == '"' {
                        if let Some(&next) = chars.peek() {
                            if next == '"' {
                                // escaped quote
                                field.push('"');
                                chars.next(); // consume second quote
                                continue;
                            } else {
                                // closing quote
                                closed = true;
                                break;
                            }
                        } else {
                            // closing quote at end
                            closed = true;
                            break;
                        }
                    } else {
                        field.push(c2);
                    }
                }
                if !closed {
                    return None;
                }
                // after closing quote, next char must be comma or end
                if let Some(&next) = chars.peek() {
                    if next != ',' {
                        return None;
                    }
                }
            } else {
                // unquoted
                while let Some(&c2) = chars.peek() {
                    if c2 == ',' {
                        break;
                    }
                    if c2 == '"' {
                        return None; // stray quote
                    }
                    field.push(c2);
                    chars.next();
                }
            }
        }
        fields.push(field);
        // If we consumed all chars, break
        if chars.peek().is_none() {
            break;
        }
        // Expect comma
        if let Some(&',') = chars.peek() {
            chars.next(); // consume comma
            // continue to next field
        } else {
            return None;
        }
    }
    Some(fields)
}
