//! TODO: Port reference.c csv_parse. One CSV record, comma separated; empty
//! fields allowed. Quotes only at field start, doubled quotes escape a quote,
//! quoted fields may contain commas. After closing quote only comma/end allowed.
//! Reject unclosed/stray quotes and CR/LF anywhere. Preserve all field contents.
pub fn parse_line(text: &str) -> Option<Vec<String>> {
    if text.contains('\r') || text.contains('\n') {
        return None;
    }
    let chars: Vec<char> = text.chars().collect();
    let mut fields = Vec::new();
    let mut i = 0usize;
    while i <= chars.len() {
        if i > chars.len() {
            break;
        }
        let mut field = String::new();
        if i < chars.len() && chars[i] == '"' {
            i += 1; // skip opening quote
            let mut closed = false;
            loop {
                if i >= chars.len() {
                    return None; // unclosed quote
                }
                let c = chars[i];
                if c == '"' {
                    i += 1;
                    if i < chars.len() && chars[i] == '"' {
                        field.push('"');
                        i += 1;
                        continue;
                    } else {
                        closed = true;
                        break;
                    }
                } else {
                    field.push(c);
                    i += 1;
                }
            }
            if !closed {
                return None;
            }
            // after closing quote only comma or end allowed
            if i < chars.len() && chars[i] != ',' {
                return None;
            }
        } else {
            // unquoted field
            while i < chars.len() && chars[i] != ',' {
                let c = chars[i];
                if c == '"' {
                    return None; // stray quote
                }
                field.push(c);
                i += 1;
            }
        }
        fields.push(field);
        if i >= chars.len() {
            break;
        }
        // skip comma separator
        if chars[i] == ',' {
            i += 1;
        } else {
            // should not happen
            return None;
        }
    }
    Some(fields)
}
