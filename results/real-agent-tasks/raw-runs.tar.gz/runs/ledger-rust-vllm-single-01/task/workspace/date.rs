//! TODO: Port reference.c date_valid: exact ASCII YYYY-MM-DD, Gregorian date,
//! year 0001..9999, actual month length and century-aware leap years.
pub fn valid(text: &str) -> bool {
    let bytes = text.as_bytes();
    if bytes.len() != 10 { return false; }
    if bytes[4] != b'-' || bytes[7] != b'-' { return false; }
    for (i, &b) in bytes.iter().enumerate() {
        if i == 4 || i == 7 { continue; }
        if !b.is_ascii_digit() { return false; }
    }
    let year = parse_u16(&bytes[0..4]) as u32;
    let month = parse_u8(&bytes[5..7]) as u32;
    let day = parse_u8(&bytes[8..10]) as u32;
    if year < 1 || year > 9999 { return false; }
    if month < 1 || month > 12 { return false; }
    let days_in_month = match month {
        1 | 3 | 5 | 7 | 8 | 10 | 12 => 31,
        4 | 6 | 9 | 11 => 30,
        2 => {
            let leap = (year % 4 == 0) && (year % 100 != 0 || year % 400 == 0);
            if leap { 29 } else { 28 }
        }
        _ => 0,
    };
    if day < 1 || day > days_in_month { return false; }
    true
}

fn parse_u16(slice: &[u8]) -> u16 {
    let mut v = 0u16;
    for &b in slice {
        v = v * 10 + (b - b'0') as u16;
    }
    v
}
fn parse_u8(slice: &[u8]) -> u8 {
    let mut v = 0u8;
    for &b in slice {
        v = v * 10 + (b - b'0');
    }
    v
}
