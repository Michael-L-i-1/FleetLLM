//! TODO: Port reference.c normalize: trim/collapse ASCII whitespace to one
//! ordinary space; lowercase ASCII A-Z; preserve non-ASCII characters unchanged.
pub fn normalize(text: &str) -> String {
    let mut out = String::new();
    let mut pending_space = false;
    for ch in text.chars() {
        if is_ascii_whitespace(ch) {
            pending_space = true;
        } else {
            if pending_space {
                if !out.is_empty() {
                    out.push(' ');
                }
                pending_space = false;
            }
            let mut c = ch;
            if c.is_ascii_uppercase() {
                c = (c as u8 + 32) as char;
            }
            out.push(c);
        }
    }
    // trim trailing space if pending
    if pending_space && !out.is_empty() {
        while out.ends_with(' ') {
            out.pop();
        }
    }
    out
}

fn is_ascii_whitespace(ch: char) -> bool {
    matches!(ch, ' ' | '\t' | '\n' | '\r' | '\x0b' | '\x0c')
}
