//! TODO: Port reference.c csv_parse. One CSV record, comma separated; empty
//! fields allowed. Quotes only at field start, doubled quotes escape a quote,
//! quoted fields may contain commas. After closing quote only comma/end allowed.
//! Reject unclosed/stray quotes and CR/LF anywhere. Preserve all field contents.
pub fn parse_line(text: &str) -> Option<Vec<String>> {
    // Reject CR/LF anywhere
    if text.bytes().any(|b| b == b'\r' || b == b'\n') { return None; }
    let bytes = text.as_bytes();
    let mut fields: Vec<String> = Vec::new();
    let mut i = 0;
    let len = bytes.len();
    while i <= len {
        let mut field_bytes: Vec<u8> = Vec::new();
        if i < len && bytes[i] == b'"' {
            // quoted field
            i += 1;
            let mut in_quotes = true;
            while in_quotes {
                if i >= len { return None; } // unclosed
                if bytes[i] == b'"' {
                    // check doubled quote
                    if i + 1 < len && bytes[i + 1] == b'"' {
                        field_bytes.push(b'"');
                        i += 2;
                        continue;
                    } else {
                        // closing quote
                        i += 1;
                        // after closing quote, must be comma or end
                        if i < len && bytes[i] != b',' { return None; }
                        in_quotes = false;
                        continue;
                    }
                } else {
                    field_bytes.push(bytes[i]);
                    i += 1;
                }
            }
        } else {
            // unquoted
            let start = i;
            while i < len && bytes[i] != b',' {
                if bytes[i] == b'"' { return None; } // stray quote
                i += 1;
            }
            field_bytes.extend_from_slice(&bytes[start..i]);
        }
        // field collected
        let s = String::from_utf8(field_bytes).ok()?;
        fields.push(s);
        if i >= len { break; }
        // skip comma
        if bytes[i] == b',' {
            i += 1;
            continue;
        } else {
            // should not happen
            return None;
        }
    }
    Some(fields)
}
