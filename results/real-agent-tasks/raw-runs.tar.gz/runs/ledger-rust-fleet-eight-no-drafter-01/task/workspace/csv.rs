//! TODO: Port reference.c csv_parse. One CSV record, comma separated; empty
//! fields allowed. Quotes only at field start, doubled quotes escape a quote,
//! quoted fields may contain commas. After closing quote only comma/end allowed.
//! Reject unclosed/stray quotes and CR/LF anywhere. Preserve all field contents.
pub fn parse_line(text: &str) -> Option<Vec<String>> {
    if text.chars().any(|c| c == '\r' || c == '\n') {
        return None;
    }
    let bytes = text.as_bytes();
    let mut i = 0;
    let len = bytes.len();
    let mut fields = Vec::new();

    loop {
        if i > len {
            return None;
        }
        let mut field = String::new();
        if i < len && bytes[i] == b'"' {
            // quoted field
            i += 1; // skip opening quote
            let mut closed = false;
            while i < len {
                let c = bytes[i];
                if c == b'"' {
                    i += 1;
                    if i < len && bytes[i] == b'"' {
                        // escaped quote
                        field.push('"');
                        i += 1;
                    } else {
                        // closing quote
                        closed = true;
                        i += 1;
                        break;
                    }
                } else {
                    field.push(c as char);
                    i += 1;
                }
            }
            if !closed {
                return None; // unclosed quote
            }
            // after closing quote, only comma or end allowed
            if i < len && bytes[i] != b',' {
                return None;
            }
        } else {
            // unquoted field
            while i < len && bytes[i] != b',' {
                let c = bytes[i];
                if c == b'"' {
                    return None; // stray quote
                }
                field.push(c as char);
                i += 1;
            }
        }
        fields.push(field);
        if i >= len {
            break;
        }
        // skip comma
        if bytes[i] == b',' {
            i += 1;
            // continue to next field
        } else {
            // should not happen
            return None;
        }
    }
    Some(fields)
}
