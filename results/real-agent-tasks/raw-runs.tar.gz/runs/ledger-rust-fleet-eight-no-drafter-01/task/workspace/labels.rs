//! TODO: Port reference.c normalize: trim/collapse ASCII whitespace to one
//! ordinary space; lowercase ASCII A-Z; preserve non-ASCII characters unchanged.
pub fn normalize(text: &str) -> String {
    fn is_space(c: char) -> bool {
        matches!(c, ' ' | '\t' | '\n' | '\r' | '\x0b' | '\x0c')
    }
    let mut out = String::new();
    let mut pending = false;
    for ch in text.chars() {
        if is_space(ch) {
            if !out.is_empty() {
                pending = true;
            }
        } else {
            if pending {
                out.push(' ');
                pending = false;
            }
            let lc = if ch.is_ascii_uppercase() { ch.to_ascii_lowercase() } else { ch };
            out.push(lc);
        }
    }
    out
}
