//! TODO: Port reference.c dedupe_rows. Keep FIRST record for each exact ID in
//! original order. Return each repeated ID once, sorted lexicographically, in
//! the second vector. IDs are case sensitive. Do not mutate the input.
use crate::Record;
use std::collections::HashSet;

pub fn dedupe(rows: &[Record]) -> (Vec<Record>, Vec<String>) {
    let mut seen = HashSet::new();
    let mut deduped = Vec::with_capacity(rows.len());
    let mut dup_set = HashSet::new();

    for r in rows {
        if !seen.contains(&r.id) {
            seen.insert(r.id.clone());
            deduped.push(r.clone());
        } else {
            dup_set.insert(r.id.clone());
        }
    }

    let mut duplicates: Vec<String> = dup_set.into_iter().collect();
    duplicates.sort();
    (deduped, duplicates)
}
